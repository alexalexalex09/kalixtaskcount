# kalixtaskcount
A Chrome extension for displaying task counts in Kalix
